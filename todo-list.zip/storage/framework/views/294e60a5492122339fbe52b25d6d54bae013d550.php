<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-Zenh87qX5JnK2Jl0vWa8Ck2rdkQ2Bzep5IDxbcnCeuOxjzrPF/et3URy9Bv1WTRi" crossorigin="anonymous">
    <title>To Do List</title>
</head>
<body>
    <div class="container">
    <div class="text-center mt-4">
        <a href="<?php echo e(route('add')); ?>" class="btn btn-primary">Tambah todolist</a>
        <a href="<?php echo e(route('add_mhs')); ?>" class="btn btn-secondary">Tambah Mahasiswa</a>
    </div>
        <table cellspacing="0" cellpadding="5" class="table my-5 table-striped">
            <thead>
                <tr class="text-center">
                    <th>No</th>
                    <th>Nama</th>
                    <th>To do</th>
                    <th>Keterangan</th>
                    <th>Status</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php $i = 1?>
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td class="text-center"><?php echo e($i); ?></td>
                        <td><?php echo e($item->nama); ?></td>
                        <td><?php echo e($item->todo); ?></td>
                        <td><?php echo e($item->keterangan); ?></td>
                        <td class="text-center">
                            <?php if($item->is_done == 0): ?>
                                <span class="badge text-bg-secondary">On Progress</span>
                            <?php else: ?>
                                <span class="badge text-bg-success">Done</span>
                            <?php endif; ?>
                        </td>
                        <td class="text-center"><a class="btn btn-warning" href="<?php echo e(url('/show/'.$item->id)); ?>">Edit</a> | 
                            <a class="btn btn-danger" href="<?php echo e(url('/delete/'.$item->id)); ?>">Delete</a></td>
                    </tr>
                <?php $i++; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</body>
</html><?php /**PATH E:\Kuliah\Akademik\Semester 3\Workshop Framework\project\todo-list\resources\views/index.blade.php ENDPATH**/ ?>