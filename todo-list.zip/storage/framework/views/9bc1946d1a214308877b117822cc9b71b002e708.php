<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Tambah To Do List</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-Zenh87qX5JnK2Jl0vWa8Ck2rdkQ2Bzep5IDxbcnCeuOxjzrPF/et3URy9Bv1WTRi" crossorigin="anonymous">
  </head>
  <body>
    <div class="container">
        <h1 class="text-center mt-5">Update To Do List</h1>
        <form action="<?php echo e(url('/update/'.$data->id)); ?>" method="post">
            <?php echo csrf_field(); ?>
            <div class="row justify-content-center mb-5">
                <div class="col-6">
                    <div class="mb-3">
                        <label for="mhs">Mahasiswa</label>
                        <select class="form-control" name="mhs" id="mhs">
                            <option value="<?php echo e($mhs_active->id); ?>"><?php echo e($mhs_active->nama); ?></option>
                            <?php $__currentLoopData = $mahasiswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mhs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($mhs->id); ?>"><?php echo e($mhs->nama); ?></option> 
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label for="todo" class="form-label">To Do</label>
                        <input type="text" class="form-control" id="todo" name="todo" value="<?php echo e($data->todo); ?>">
                    </div>
                    <div class="mb-3">
                        <label for="keterangan" class="form-label">Keterangan</label>
                        <textarea name="keterangan" id="keterangan" cols="30" rows="5" class="form-control"><?php echo e($data->keterangan); ?></textarea>
                    </div>

                    <?php if($data->is_done): ?>
                        <input type="checkbox" name="is_done" id="done" checked>
                    <?php else: ?>
                        <input type="checkbox" name="is_done" id="done">
                    <?php endif; ?>
                    <label for="done" class="mb-3" checked>Tandai Sudah Selesai</label>  
                    <button type="submit" class="btn btn-primary w-100 text-center">Submit</button>
                    <a href="<?php echo e(route('index')); ?>" class="btn btn-light w-100 text-center mt-3">Cancel</a>
                </div>
            </div>
        </form>
      </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-OERcA2EqjJCMA+/3y+gxIOqMEjwtxJY7qPCqsdltbNJuaOe923+mo//f6V8Qbsw3" crossorigin="anonymous"></script>
  </body>
</html><?php /**PATH E:\Kuliah\Akademik\Semester 3\Workshop Framework\project\todo-list\resources\views/show.blade.php ENDPATH**/ ?>